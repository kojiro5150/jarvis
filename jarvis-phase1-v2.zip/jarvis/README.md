# JARVIS — Phase 1

Personal AI dashboard shell. Next.js (App Router, TypeScript, Tailwind), deployable free on Vercel. Single-user, not commercial.

## Design Philosophy

JARVIS is an executive operating layer, not a chatbot. This shapes every prompt and every line of UI copy in this repo — read this before adding features or editing agent prompts, so new work doesn't regress the character.

1. **State, not implementation.** JARVIS reports what's known, tracked, connected, or pending — never APIs, databases, memory layers, or missing connectors. Those only come up if Sam explicitly asks how the system works. This is a UI/copy rule as much as a prompt rule: no "Phase 1" badges, no vendor names, no build-status language in anything Sam sees during normal use.
2. **Never open with a limitation.** Every response leads with what's known, then what's inferred, then — only if truly relevant — the specific gap, stated once and briefly. Never "I don't have access to..." as an opener.
3. **Show, don't announce.** JARVIS doesn't reintroduce itself as "the orchestrator" each session. It acts like one.
4. **Every session opens with a stance.** The console seeds itself with a computed executive brief (see `lib/briefing.ts`) instead of an empty "nothing sent yet" state — even before Sam types anything.
5. **Character, not verbosity.** Calm, confident, precise, economical. Executive chief of staff, not an assistant chatbot.
6. **Agents are specialists with bounded roles**, not personalities. JARVIS coordinates; ORACLE researches; HERALD writes; PHDSS reasons about risk; and so on. None of them narrate what kind of agent they are.

The shared rules live in `lib/agents/persona.ts` (`CHARACTER_RULES` / `withCharacter()`) and are appended to every agent's system prompt in `lib/agents/*.ts` — tune tone there once rather than per agent. `lib/briefing.ts` generates the per-agent opening state from current local data (`lib/placeholder-data.ts`) with no model call, so it renders instantly.

One deliberate exception: **STEVE** (Engineering) is allowed to discuss the actual stack (Next.js, Vercel, Supabase, etc.) because that's literally the job when Sam is in an engineering conversation with him — principle 1 only restricts *unprompted* architecture talk from the other seven.

## What's in Phase 1

- Dashboard shell: agent rail, top bar, central command console with animated orb, right-hand voice/quick-command panel, and static placeholder cards (priorities, calendar, projects, agent status, insights).
- 8 agents — JARVIS, DAWNWATCH, ORACLE, HERALD, STEVE, CO-WORK, PHDSS, MARCUS — each defined in its own file under `lib/agents/`, with its own system prompt and accent color.
- `/api/chat` — a server-only route that calls the Claude API. Your Anthropic key never reaches the browser.
- State is local/static (React state + hardcoded placeholder data). No database yet — that's Phase 2 (Supabase Free).
- Voice (ElevenLabs) is stubbed in the UI but not wired up — that's a later phase.

## Project structure

```
jarvis/
  app/
    api/chat/route.ts       # server-side Claude call, reads ANTHROPIC_API_KEY
    layout.tsx
    page.tsx                # composes the dashboard shell
    globals.css
  components/
    AgentRail.tsx            # left-hand agent list
    TopBar.tsx                # greeting + clock
    Orb.tsx                    # animated orb, colored per active agent
    CommandConsole.tsx    # chat UI, calls /api/chat
    RightPanel.tsx            # voice placeholder + quick commands + memory note
    cards/
      PrioritiesCard.tsx
      CalendarCard.tsx
      ProjectsCard.tsx
      AgentStatusCard.tsx
      SignalsRow.tsx
  lib/
    agents/
      types.ts                  # AgentDefinition shape
      accent.ts                 # static Tailwind class map per accent color
      persona.ts                 # shared character rules, applied to every agent prompt
      jarvis.ts, dawnwatch.ts, oracle.ts, herald.ts,
      steve.ts, cowork.ts, phdss.ts, marcus.ts   # one file per agent
      index.ts                   # AGENTS list + getAgent(id)
    claude.ts                    # server-only Anthropic SDK wrapper
    briefing.ts                    # computes each agent's opening executive brief, no model call
    placeholder-data.ts     # local state behind the cards and the briefing (Phase 1 only)
  .env.local.example
  tailwind.config.ts
  next.config.mjs
```

## Run it locally

```bash
cd jarvis
npm install                      # already run for you if you got this via the assistant
cp .env.local.example .env.local
# edit .env.local and set ANTHROPIC_API_KEY=sk-ant-...
npm run dev
```

Open http://localhost:3000. Click an agent in the left rail, then type into the console — it calls `/api/chat`, which calls Claude server-side with that agent's system prompt.

If the console shows "Intelligence link not established," `.env.local` isn't set (or the dev server needs a restart after editing it).

## Deploy to Vercel (Free tier)

1. Push this `jarvis/` folder to a GitHub repo (or `vercel` CLI can deploy directly without git).
2. On [vercel.com](https://vercel.com), "Add New Project" → import the repo.
3. In Project Settings → Environment Variables, add `ANTHROPIC_API_KEY` (and leave `ELEVENLABS_API_KEY` blank for now — it's unused in Phase 1).
4. Deploy. Vercel's Free (Hobby) tier covers this comfortably — one Next.js app, serverless API route, no database yet.
5. Because Phase 1 has no server session/auth, don't put anything sensitive in placeholder data before you add real auth. It's fine for now since it's static and public only to you via the URL, but Vercel Hobby URLs are reachable by anyone with the link — consider Vercel's password-protection (Pro feature) or wait until real auth exists in a later phase if that matters to you.

## Security notes

- `ANTHROPIC_API_KEY` is read only inside `lib/claude.ts` and `app/api/chat/route.ts` — both server-only. It is never sent to the client bundle and is not prefixed with `NEXT_PUBLIC_`.
- The chat route validates input shape/length before calling Claude, and never echoes internal error details (stack traces, key hints) back to the browser.
- `.env.local` is git-ignored via `.gitignore`.

## What's deliberately deferred to later phases

- **Supabase Free** for persistent memory/state (conversation history per agent, priorities/calendar/projects backed by real tables instead of `lib/placeholder-data.ts`).
- **ElevenLabs** voice input/output — the mic button in `RightPanel.tsx` is a visual placeholder only.
- **Live connectors** (real calendar, email, project data) — agents currently ground answers in local state (`lib/placeholder-data.ts`) and whatever Sam gives them in-session, rather than inventing specifics. Per the Design Philosophy above, they never call this out as a limitation unless Sam explicitly asks how the system works.
- **Auth** — Phase 1 assumes single-user, no login. Add this before putting anything sensitive behind the URL.

## Next steps (Phase 2 preview)

- Add `@supabase/supabase-js`, create tables for `conversations`, `messages`, `priorities`, `projects`.
- Swap `lib/placeholder-data.ts` reads for Supabase queries (server components or a small `lib/db.ts`).
- Add ElevenLabs TTS: a server route `app/api/speak/route.ts` that takes agent reply text and returns audio, called from `CommandConsole.tsx` after a reply arrives.
- Add simple auth (e.g. a single shared passphrase via middleware) before deploying anywhere public.
