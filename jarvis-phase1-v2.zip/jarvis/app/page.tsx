"use client";

import { useState } from "react";
import AgentRail from "@/components/AgentRail";
import TopBar from "@/components/TopBar";
import CommandConsole from "@/components/CommandConsole";
import RightPanel from "@/components/RightPanel";
import PrioritiesCard from "@/components/cards/PrioritiesCard";
import CalendarCard from "@/components/cards/CalendarCard";
import ProjectsCard from "@/components/cards/ProjectsCard";
import AgentStatusCard from "@/components/cards/AgentStatusCard";
import SignalsRow from "@/components/cards/SignalsRow";
import { getAgent } from "@/lib/agents";

export default function Home() {
  const [selectedId, setSelectedId] = useState("jarvis");
  const [presetText, setPresetText] = useState("");
  const [presetNonce, setPresetNonce] = useState(0);

  const agent = getAgent(selectedId);

  function handleQuickCommand(text: string) {
    setPresetText(text);
    setPresetNonce((n) => n + 1);
  }

  return (
    <div className="h-screen w-screen flex overflow-hidden">
      <AgentRail selectedId={selectedId} onSelect={setSelectedId} />

      <div className="flex-1 flex flex-col min-w-0">
        <TopBar agent={agent} />

        <div className="flex-1 flex min-h-0">
          <CommandConsole
            key={agent.id}
            agent={agent}
            presetText={presetText}
            presetNonce={presetNonce}
          />
          <RightPanel accent={agent.accent} onQuickCommand={handleQuickCommand} />
        </div>

        <div className="px-6 pb-6 pt-2 space-y-4 overflow-y-auto shrink-0 max-h-[46%]">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            <PrioritiesCard />
            <CalendarCard />
            <AgentStatusCard />
          </div>
          <div className="grid grid-cols-1 xl:grid-cols-1 gap-4">
            <ProjectsCard />
          </div>
          <SignalsRow />
        </div>
      </div>
    </div>
  );
}
