"use client";

import { AGENTS } from "@/lib/agents";
import { accentClasses } from "@/lib/agents/accent";

interface AgentRailProps {
  selectedId: string;
  onSelect: (id: string) => void;
}

export default function AgentRail({ selectedId, onSelect }: AgentRailProps) {
  return (
    <aside className="w-56 shrink-0 h-full panel border-r border-white/5 flex flex-col">
      <div className="flex items-center gap-2 px-5 py-6">
        <div className="h-7 w-7 rounded border border-cyan-400/40 bg-cyan-400/10 flex items-center justify-center text-cyan-300 text-xs font-bold">
          J
        </div>
        <span className="text-sm font-semibold tracking-widest text-white/90">
          JARVIS
        </span>
      </div>

      <nav className="flex-1 overflow-y-auto px-2 space-y-1">
        {AGENTS.map((agent) => {
          const isActive = agent.id === selectedId;
          const c = accentClasses(agent.accent);
          const Icon = agent.icon;
          return (
            <button
              key={agent.id}
              onClick={() => onSelect(agent.id)}
              className={`w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-left transition-colors border ${
                isActive
                  ? `${c.bg} ${c.border} ${c.text}`
                  : "border-transparent text-white/50 hover:bg-white/5 hover:text-white/80"
              }`}
            >
              <Icon
                size={18}
                strokeWidth={1.75}
                className={isActive ? c.text : "text-white/40"}
              />
              <div className="min-w-0">
                <div className="text-xs font-semibold tracking-wide truncate">
                  {agent.name}
                </div>
                <div className="text-[10px] text-white/40 truncate">
                  {agent.subtitle}
                </div>
              </div>
            </button>
          );
        })}
      </nav>

      <div className="px-4 py-4 border-t border-white/5">
        <div className="flex items-center gap-2 text-[11px] text-white/40">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse-slow" />
          JARVIS ONLINE
        </div>
      </div>
    </aside>
  );
}
