"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Send, Loader2 } from "lucide-react";
import Orb from "./Orb";
import { accentClasses } from "@/lib/agents/accent";
import { getOpeningBrief } from "@/lib/briefing";
import type { AgentDefinition, ChatMessage } from "@/lib/agents/types";

interface CommandConsoleProps {
  agent: AgentDefinition;
  /** Bumping this alongside a new `presetText` fills the input (e.g. from a quick command). */
  presetText?: string;
  presetNonce?: number;
}

export default function CommandConsole({
  agent,
  presetText,
  presetNonce,
}: CommandConsoleProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (presetText) setInput(presetText);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [presetNonce]);

  const c = accentClasses(agent.accent);
  const brief = useMemo(() => getOpeningBrief(agent.id), [agent.id]);

  async function send(text: string) {
    const trimmed = text.trim();
    if (!trimmed || loading) return;

    const nextMessages: ChatMessage[] = [
      ...messages,
      { role: "user", content: trimmed },
    ];
    setMessages(nextMessages);
    setInput("");
    setLoading(true);
    setError(null);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ agentId: agent.id, messages: nextMessages }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Request failed.");
      setMessages([
        ...nextMessages,
        { role: "assistant", content: data.reply },
      ]);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Intelligence link interrupted. Try again."
      );
    } finally {
      setLoading(false);
      requestAnimationFrame(() => {
        scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight });
      });
    }
  }

  return (
    <div className="flex flex-col items-center flex-1 h-full px-6 py-8 min-w-0">
      <Orb accent={agent.accent} active={loading} size={180} />

      <p className={`mt-4 text-sm italic ${c.textDim}`}>
        {loading ? `${agent.name} is thinking...` : `"${agent.description}"`}
      </p>

      <div
        ref={scrollRef}
        className="w-full max-w-xl flex-1 mt-6 overflow-y-auto space-y-3 min-h-0"
      >
        <div
          className={`rounded-xl px-4 py-2.5 text-sm leading-relaxed max-w-[90%] mr-auto panel border ${c.border} ${c.text}`}
        >
          {brief}
        </div>
        {messages.map((m, i) => (
          <div
            key={i}
            className={`rounded-xl px-4 py-2.5 text-sm leading-relaxed max-w-[90%] ${
              m.role === "user"
                ? "ml-auto bg-white/10 text-white/90"
                : `mr-auto panel border ${c.border} ${c.text}`
            }`}
          >
            {m.content}
          </div>
        ))}
        {error && (
          <div className="rounded-xl px-4 py-2.5 text-sm bg-rose-500/10 border border-rose-400/30 text-rose-300 max-w-[90%]">
            {error}
          </div>
        )}
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          send(input);
        }}
        className="w-full max-w-xl mt-5 flex items-center gap-2"
      >
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={`Ask ${agent.name}...`}
          className={`flex-1 rounded-full bg-white/5 border ${c.border} px-4 py-2.5 text-sm text-white/90 placeholder-white/30 outline-none focus:ring-2 ${c.ring}`}
        />
        <button
          type="submit"
          disabled={loading || !input.trim()}
          className={`h-10 w-10 shrink-0 rounded-full ${c.bg} border ${c.border} flex items-center justify-center ${c.text} disabled:opacity-40 transition-opacity`}
        >
          {loading ? (
            <Loader2 size={16} className="animate-spin" />
          ) : (
            <Send size={16} />
          )}
        </button>
      </form>
    </div>
  );
}
