"use client";

import { accentClasses } from "@/lib/agents/accent";
import type { AgentAccent } from "@/lib/agents/types";

interface OrbProps {
  accent: AgentAccent;
  active?: boolean;
  size?: number;
}

/**
 * Futuristic holographic orb — pure CSS/SVG, no assets, no external deps.
 * `active` pulses faster/brighter to indicate the agent is thinking/speaking.
 */
export default function Orb({ accent, active = false, size = 220 }: OrbProps) {
  const c = accentClasses(accent);

  return (
    <div
      className="relative flex items-center justify-center"
      style={{ width: size, height: size }}
    >
      {/* outer rotating ring */}
      <div
        className={`absolute inset-0 rounded-full border ${c.border} animate-spin-slow`}
        style={{ borderStyle: "dashed" }}
      />
      {/* inner counter-rotating ring */}
      <div
        className={`absolute inset-4 rounded-full border ${c.border} opacity-60 animate-spin-reverse-slow`}
      />
      {/* soft outer glow */}
      <div
        className={`absolute inset-6 rounded-full ${c.bgSoft} blur-2xl ${
          active ? "animate-pulse-slow" : ""
        }`}
      />
      {/* core */}
      <div
        className={`relative rounded-full ${c.bg} ${c.glow} border ${c.border} flex items-center justify-center animate-drift`}
        style={{ width: size * 0.55, height: size * 0.55 }}
      >
        <div
          className={`rounded-full ${c.bg} ${
            active ? "animate-pulse-slow" : ""
          }`}
          style={{ width: "60%", height: "60%" }}
        />
      </div>
      {/* orbiting dot */}
      <div className="absolute inset-0 animate-spin-slow">
        <div
          className={`absolute top-0 left-1/2 -translate-x-1/2 h-2 w-2 rounded-full ${c.dot} ${c.glow}`}
        />
      </div>
    </div>
  );
}
