"use client";

import { Mic } from "lucide-react";
import { accentClasses } from "@/lib/agents/accent";
import type { AgentAccent } from "@/lib/agents/types";

const QUICK_COMMANDS = [
  "Brief me on today",
  "Prepare for my next meeting",
  "Summarize what needs my attention",
  "Draft a status update",
];

interface RightPanelProps {
  accent: AgentAccent;
  onQuickCommand: (text: string) => void;
}

export default function RightPanel({ accent, onQuickCommand }: RightPanelProps) {
  const c = accentClasses(accent);

  return (
    <aside className="w-72 shrink-0 h-full panel border-l border-white/5 flex flex-col overflow-y-auto">
      <div className="px-5 py-6 border-b border-white/5">
        <div className="text-[11px] tracking-widest text-white/40 mb-4">
          VOICE INTERFACE
        </div>
        <div className="flex flex-col items-center">
          <div
            className={`h-16 w-16 rounded-full border ${c.border} ${c.bg} flex items-center justify-center`}
          >
            <Mic size={20} className={c.text} />
          </div>
          <p className="text-xs text-white/40 mt-3 text-center">
            Voice channel standing by.
          </p>
          <button
            disabled
            className="mt-3 w-full rounded-full border border-white/10 text-white/30 text-xs py-2 cursor-not-allowed"
          >
            Voice offline — type below
          </button>
        </div>
      </div>

      <div className="px-5 py-6 border-b border-white/5">
        <div className="text-[11px] tracking-widest text-white/40 mb-3">
          QUICK COMMANDS
        </div>
        <div className="space-y-2">
          {QUICK_COMMANDS.map((cmd) => (
            <button
              key={cmd}
              onClick={() => onQuickCommand(cmd)}
              className="w-full text-left text-xs rounded-lg border border-white/10 px-3 py-2.5 text-white/60 hover:text-white/90 hover:border-white/20 hover:bg-white/5 transition-colors"
            >
              {cmd}
            </button>
          ))}
        </div>
      </div>

      <div className="px-5 py-6">
        <div className="text-[11px] tracking-widest text-white/40 mb-3">
          MEMORY
        </div>
        <div className="rounded-lg border border-white/10 px-3 py-3 text-xs text-white/50">
          Session recall active. Long-term recall not yet established.
        </div>
      </div>
    </aside>
  );
}
