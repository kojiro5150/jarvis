"use client";

import { useEffect, useState } from "react";
import { Settings } from "lucide-react";
import type { AgentDefinition } from "@/lib/agents/types";

function getGreeting(hour: number): string {
  if (hour < 5) return "Good night";
  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
}

export default function TopBar({ agent }: { agent: AgentDefinition }) {
  const [now, setNow] = useState<Date | null>(null);

  useEffect(() => {
    setNow(new Date());
    const id = setInterval(() => setNow(new Date()), 1000 * 30);
    return () => clearInterval(id);
  }, []);

  const greeting = now ? getGreeting(now.getHours()) : "Hello";

  return (
    <header className="flex items-center justify-between px-6 py-5 border-b border-white/5">
      <div>
        <h1 className="text-lg font-semibold text-white/90">
          {greeting}, Sam.
        </h1>
        <p className="text-xs text-white/40">
          {agent.isPrimary
            ? "I've reviewed your world. Here's what matters."
            : `${agent.name} — ${agent.description}`}
        </p>
      </div>
      <div className="flex items-center gap-4 text-right">
        {now && (
          <div>
            <div className="text-[10px] tracking-widest text-white/40">
              {now
                .toLocaleDateString("en-US", { weekday: "long" })
                .toUpperCase()}
            </div>
            <div className="text-sm font-mono text-white/80">
              {now.toLocaleTimeString("en-US", {
                hour: "2-digit",
                minute: "2-digit",
              })}
            </div>
          </div>
        )}
        <button className="h-8 w-8 rounded-full border border-white/10 flex items-center justify-center text-white/40 hover:text-white/70 hover:border-white/20 transition-colors">
          <Settings size={15} />
        </button>
      </div>
    </header>
  );
}
