import { AGENTS } from "@/lib/agents";
import { accentClasses } from "@/lib/agents/accent";

export default function AgentStatusCard() {
  return (
    <div className="panel rounded-xl border border-white/5 p-5 flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xs tracking-widest text-white/50">
          AGENT STATUS
        </h3>
        <span className="text-[10px] text-emerald-400/70">All Ready</span>
      </div>
      <div className="space-y-2.5">
        {AGENTS.map((agent) => {
          const c = accentClasses(agent.accent);
          const Icon = agent.icon;
          return (
            <div key={agent.id} className="flex items-center gap-2.5">
              <Icon size={14} className={c.text} />
              <div className="min-w-0 flex-1">
                <div className="text-xs text-white/80 truncate">
                  {agent.name}
                </div>
                <div className="text-[10px] text-white/30 truncate">
                  {agent.subtitle}
                </div>
              </div>
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
            </div>
          );
        })}
      </div>
    </div>
  );
}
