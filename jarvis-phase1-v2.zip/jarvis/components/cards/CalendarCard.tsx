import { CALENDAR_EVENTS } from "@/lib/placeholder-data";

export default function CalendarCard() {
  return (
    <div className="panel rounded-xl border border-white/5 p-5 flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xs tracking-widest text-white/50">
          CALENDAR SNAPSHOT
        </h3>
        <span className="text-[10px] text-white/30">Next 3</span>
      </div>
      <div className="space-y-3">
        {CALENDAR_EVENTS.map((ev, i) => (
          <div key={i} className="flex items-center gap-3">
            <div className="w-10 shrink-0 text-center">
              <div className="text-[10px] text-white/40">{ev.day}</div>
              <div className="text-sm font-semibold text-white/80">
                {ev.date}
              </div>
            </div>
            <div className="min-w-0 flex-1 border-l border-white/10 pl-3">
              <div className="text-sm text-white/90 truncate">{ev.title}</div>
              <div className="text-xs text-white/40">{ev.time}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
