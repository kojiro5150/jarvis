import { PRIORITIES } from "@/lib/placeholder-data";

export default function PrioritiesCard() {
  return (
    <div className="panel rounded-xl border border-white/5 p-5 flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xs tracking-widest text-white/50">
          DAWNWATCH BRIEFING
        </h3>
        <span className="flex items-center gap-1.5 text-[10px] text-emerald-400/70">
          <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
          Current
        </span>
      </div>
      <div className="space-y-3">
        {PRIORITIES.map((p) => (
          <div key={p.rank} className="flex gap-3">
            <div
              className={`h-6 w-6 shrink-0 rounded-full flex items-center justify-center text-[11px] font-semibold ${
                p.urgent
                  ? "bg-rose-400/15 text-rose-300"
                  : "bg-cyan-400/10 text-cyan-300"
              }`}
            >
              {p.rank}
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-white/90 truncate">
                  {p.title}
                </span>
                <span
                  className={`text-[10px] shrink-0 ${
                    p.urgent ? "text-rose-300" : "text-white/40"
                  }`}
                >
                  {p.due}
                </span>
              </div>
              <p className="text-xs text-white/40 mt-0.5">{p.detail}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
