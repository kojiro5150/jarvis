import { PROJECTS } from "@/lib/placeholder-data";

const BAR_COLOR: Record<string, string> = {
  cyan: "bg-cyan-400",
  amber: "bg-amber-400",
  emerald: "bg-emerald-400",
  violet: "bg-violet-400",
};

export default function ProjectsCard() {
  return (
    <div className="panel rounded-xl border border-white/5 p-5 flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xs tracking-widest text-white/50">
          PROJECTS OVERVIEW
        </h3>
        <span className="text-[10px] text-white/30">{PROJECTS.length} active</span>
      </div>
      <div className="space-y-4">
        {PROJECTS.map((p) => (
          <div key={p.name}>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-sm text-white/90">{p.name}</span>
              <span className="text-xs text-white/40">{p.progress}%</span>
            </div>
            <div className="h-1.5 rounded-full bg-white/10 overflow-hidden">
              <div
                className={`h-full rounded-full ${BAR_COLOR[p.tagColor]}`}
                style={{ width: `${p.progress}%` }}
              />
            </div>
            <div className="text-[11px] text-white/30 mt-1">{p.tag}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
