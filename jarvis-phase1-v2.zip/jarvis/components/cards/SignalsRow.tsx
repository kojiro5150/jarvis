import { AlertTriangle, Mail, Search, Clock } from "lucide-react";
import { SIGNALS, type Signal } from "@/lib/placeholder-data";

const KIND_STYLE: Record<
  Signal["kind"],
  { icon: typeof AlertTriangle; label: string; color: string }
> = {
  deadline: { icon: AlertTriangle, label: "DEADLINE", color: "text-rose-300" },
  action: { icon: Mail, label: "ACTION", color: "text-amber-300" },
  research: { icon: Search, label: "RESEARCH", color: "text-violet-300" },
  note: { icon: Clock, label: "NOTE", color: "text-cyan-300" },
};

export default function SignalsRow() {
  return (
    <div className="panel rounded-xl border border-white/5 p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xs tracking-widest text-white/50">
          INSIGHTS &amp; RECOMMENDATIONS
        </h3>
        <span className="text-[10px] text-white/30">{SIGNALS.length} flagged</span>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {SIGNALS.map((s, i) => {
          const style = KIND_STYLE[s.kind];
          const Icon = style.icon;
          return (
            <div
              key={i}
              className="rounded-lg border border-white/10 p-3.5 bg-white/[0.02]"
            >
              <div
                className={`flex items-center gap-1.5 text-[10px] tracking-wide mb-2 ${style.color}`}
              >
                <Icon size={12} />
                {style.label}
              </div>
              <div className="text-sm text-white/90">{s.title}</div>
              <p className="text-xs text-white/40 mt-1 mb-2">{s.detail}</p>
              <span className={`text-xs font-medium ${style.color}`}>
                {s.cta} &rarr;
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
