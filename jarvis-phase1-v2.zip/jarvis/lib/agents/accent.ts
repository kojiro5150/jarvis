import type { AgentAccent } from "./types";

/**
 * Tailwind needs full, static class strings to pick them up at build time —
 * so instead of building class names dynamically (`text-${accent}-400`),
 * every accent maps to a fixed bundle of classes here.
 */
export interface AccentClasses {
  text: string;
  textDim: string;
  border: string;
  bg: string;
  bgSoft: string;
  ring: string;
  glow: string;
  dot: string;
}

const ACCENT_MAP: Record<AgentAccent, AccentClasses> = {
  cyan: {
    text: "text-cyan-300",
    textDim: "text-cyan-400/70",
    border: "border-cyan-400/40",
    bg: "bg-cyan-400/10",
    bgSoft: "bg-cyan-400/5",
    ring: "ring-cyan-400/40",
    glow: "shadow-[0_0_20px_rgba(34,211,238,0.35)]",
    dot: "bg-cyan-400",
  },
  violet: {
    text: "text-violet-300",
    textDim: "text-violet-400/70",
    border: "border-violet-400/40",
    bg: "bg-violet-400/10",
    bgSoft: "bg-violet-400/5",
    ring: "ring-violet-400/40",
    glow: "shadow-[0_0_20px_rgba(167,139,250,0.35)]",
    dot: "bg-violet-400",
  },
  amber: {
    text: "text-amber-300",
    textDim: "text-amber-400/70",
    border: "border-amber-400/40",
    bg: "bg-amber-400/10",
    bgSoft: "bg-amber-400/5",
    ring: "ring-amber-400/40",
    glow: "shadow-[0_0_20px_rgba(251,191,36,0.35)]",
    dot: "bg-amber-400",
  },
  emerald: {
    text: "text-emerald-300",
    textDim: "text-emerald-400/70",
    border: "border-emerald-400/40",
    bg: "bg-emerald-400/10",
    bgSoft: "bg-emerald-400/5",
    ring: "ring-emerald-400/40",
    glow: "shadow-[0_0_20px_rgba(52,211,153,0.35)]",
    dot: "bg-emerald-400",
  },
  rose: {
    text: "text-rose-300",
    textDim: "text-rose-400/70",
    border: "border-rose-400/40",
    bg: "bg-rose-400/10",
    bgSoft: "bg-rose-400/5",
    ring: "ring-rose-400/40",
    glow: "shadow-[0_0_20px_rgba(251,113,133,0.35)]",
    dot: "bg-rose-400",
  },
  blue: {
    text: "text-blue-300",
    textDim: "text-blue-400/70",
    border: "border-blue-400/40",
    bg: "bg-blue-400/10",
    bgSoft: "bg-blue-400/5",
    ring: "ring-blue-400/40",
    glow: "shadow-[0_0_20px_rgba(96,165,250,0.35)]",
    dot: "bg-blue-400",
  },
  fuchsia: {
    text: "text-fuchsia-300",
    textDim: "text-fuchsia-400/70",
    border: "border-fuchsia-400/40",
    bg: "bg-fuchsia-400/10",
    bgSoft: "bg-fuchsia-400/5",
    ring: "ring-fuchsia-400/40",
    glow: "shadow-[0_0_20px_rgba(232,121,249,0.35)]",
    dot: "bg-fuchsia-400",
  },
  slate: {
    text: "text-slate-300",
    textDim: "text-slate-400/70",
    border: "border-slate-400/40",
    bg: "bg-slate-400/10",
    bgSoft: "bg-slate-400/5",
    ring: "ring-slate-400/40",
    glow: "shadow-[0_0_20px_rgba(148,163,184,0.35)]",
    dot: "bg-slate-400",
  },
};

export function accentClasses(accent: AgentAccent): AccentClasses {
  return ACCENT_MAP[accent];
}
