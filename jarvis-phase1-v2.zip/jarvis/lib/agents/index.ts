import type { AgentDefinition } from "./types";
import { jarvis } from "./jarvis";
import { dawnwatch } from "./dawnwatch";
import { oracle } from "./oracle";
import { herald } from "./herald";
import { steve } from "./steve";
import { cowork } from "./cowork";
import { phdss } from "./phdss";
import { marcus } from "./marcus";

export type { AgentDefinition, AgentAccent, ChatMessage } from "./types";

/** Ordered list of every agent, JARVIS first — this drives the agent rail. */
export const AGENTS: AgentDefinition[] = [
  jarvis,
  dawnwatch,
  oracle,
  herald,
  steve,
  cowork,
  phdss,
  marcus,
];

export const AGENTS_BY_ID: Record<string, AgentDefinition> = Object.fromEntries(
  AGENTS.map((agent) => [agent.id, agent])
);

export function getAgent(id: string): AgentDefinition {
  return AGENTS_BY_ID[id] ?? jarvis;
}

export { jarvis, dawnwatch, oracle, herald, steve, cowork, phdss, marcus };
