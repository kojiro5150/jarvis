import type { LucideIcon } from "lucide-react";

/**
 * Core shape of an agent definition.
 * Each agent lives in its own file under lib/agents/ so prompts,
 * personas, and metadata can be tuned independently.
 */
export interface AgentDefinition {
  /** Stable machine id, e.g. "oracle" */
  id: string;
  /** Display name, e.g. "ORACLE" */
  name: string;
  /** Short subtitle shown under the name in the rail, e.g. "Research & Insight" */
  subtitle: string;
  /** One-line description used in tooltips / headers */
  description: string;
  /** Lucide icon component */
  icon: LucideIcon;
  /** Tailwind text/border/bg color token, e.g. "cyan", "violet" */
  accent: AgentAccent;
  /** The system prompt sent to Claude when this agent is active */
  systemPrompt: string;
  /** Whether this agent is the default/orchestrator (JARVIS) */
  isPrimary?: boolean;
}

export type AgentAccent =
  | "cyan"
  | "violet"
  | "amber"
  | "emerald"
  | "rose"
  | "blue"
  | "fuchsia"
  | "slate";

export interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}
