import { PRIORITIES, PROJECTS, CALENDAR_EVENTS, SIGNALS } from "./placeholder-data";

/**
 * Every dashboard session opens with a stance, not a blank chat box.
 * This is computed locally from current state (lib/placeholder-data.ts) —
 * no model call, no network round trip, so it renders instantly and never
 * says "I don't have access to..." Once real project/calendar data is
 * connected, swap the reads inside these functions; the shape of what gets
 * returned (a short paragraph of plain text) doesn't need to change.
 */

function topProject() {
  return [...PROJECTS].sort((a, b) => b.progress - a.progress)[0];
}

function nextEvent() {
  return CALENDAR_EVENTS[0];
}

function urgentPriorities() {
  return PRIORITIES.filter((p) => p.urgent);
}

function signalsOfKind(kind: (typeof SIGNALS)[number]["kind"]) {
  return SIGNALS.filter((s) => s.kind === kind);
}

function jarvisBrief(): string {
  const urgent = urgentPriorities();
  const next = nextEvent();
  const lead = PRIORITIES[0];
  const proj = topProject();

  const urgentLine =
    urgent.length > 0
      ? `${urgent.length} item${urgent.length > 1 ? "s" : ""} need${
          urgent.length > 1 ? "" : "s"
        } attention today, top of the list: ${lead.title}.`
      : `Nothing urgent — leading priority is ${lead.title}.`;

  return [
    urgentLine,
    `${proj.name} is furthest along at ${proj.progress}%; the rest of the portfolio is moving in step behind it.`,
    `Next on the calendar: ${next.title} on ${next.day} at ${next.time}.`,
    `${SIGNALS.length} signals flagged across research, communications, and sequencing — worth a pass when you're ready.`,
  ].join(" ");
}

function dawnwatchBrief(): string {
  const urgent = urgentPriorities();
  const ranked = PRIORITIES.map((p) => `${p.rank}. ${p.title} (${p.due})`).join(" · ");
  const next = nextEvent();
  return [
    urgent.length > 0 ? `${urgent.length} urgent.` : "Nothing urgent.",
    ranked,
    `First on the calendar: ${next.title}, ${next.day} ${next.time}.`,
  ].join(" ");
}

function oracleBrief(): string {
  const research = signalsOfKind("research");
  if (research.length === 0) return "No open research threads right now. Bring a topic and I'll go deep on it.";
  return research.map((s) => `${s.title} — ${s.detail}`).join(" ");
}

function heraldBrief(): string {
  const actions = signalsOfKind("action");
  if (actions.length === 0) return "Inbox is clear — nothing waiting on a reply.";
  return actions.map((s) => `${s.title}: ${s.detail}`).join(" ");
}

function steveOrCoworkBrief(): string {
  const proj = topProject();
  const active = PROJECTS.filter((p) => p.progress > 0 && p.progress < 100);
  return `${active.length} projects in active build. ${proj.name} is closest to done at ${proj.progress}%. Bring the specific piece you want worked on.`;
}

function phdssBrief(): string {
  const deadlines = signalsOfKind("deadline");
  const notes = signalsOfKind("note");
  const flagged = [...deadlines, ...notes];
  if (flagged.length === 0) return "No open risk or sequencing questions on the board. Bring a decision and I'll pressure-test it.";
  return flagged.map((s) => `${s.title} — ${s.detail}`).join(" ");
}

function marcusBrief(): string {
  const sorted = [...PROJECTS].sort((a, b) => b.progress - a.progress);
  const summary = sorted.map((p) => `${p.name} (${p.progress}%, ${p.tag})`).join(" · ");
  return `Portfolio: ${summary}. Say the word if something needs to move or drop.`;
}

export function getOpeningBrief(agentId: string): string {
  switch (agentId) {
    case "jarvis":
      return jarvisBrief();
    case "dawnwatch":
      return dawnwatchBrief();
    case "oracle":
      return oracleBrief();
    case "herald":
      return heraldBrief();
    case "steve":
    case "cowork":
      return steveOrCoworkBrief();
    case "phdss":
      return phdssBrief();
    case "marcus":
      return marcusBrief();
    default:
      return jarvisBrief();
  }
}
