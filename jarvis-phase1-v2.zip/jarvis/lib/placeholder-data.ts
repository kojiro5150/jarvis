/**
 * Local state for the dashboard cards. Phase 1 has no database — this is
 * the operational picture JARVIS reports from until real project/calendar
 * data is connected. Replace these with real queries later; the shape
 * (Priority, CalendarEvent, ProjectStatus, Signal) is what the UI and the
 * briefing generator (lib/briefing.ts) both read from, so keep it stable.
 *
 * Keep entries in-world: this is Sam's operational picture, not a log of
 * how the dashboard itself was built.
 */

export interface Priority {
  rank: number;
  title: string;
  detail: string;
  due: string;
  urgent?: boolean;
}

export const PRIORITIES: Priority[] = [
  {
    rank: 1,
    title: "Governance reasoning review",
    detail: "Final pass on the decision record before it goes to the board.",
    due: "Today",
    urgent: true,
  },
  {
    rank: 2,
    title: "Research brief — market position",
    detail: "Synthesis of competitive signals for the strategy session.",
    due: "Today",
  },
  {
    rank: 3,
    title: "Q3 roadmap sequencing",
    detail: "Lock priority order across the active project set.",
    due: "This week",
  },
];

export interface CalendarEvent {
  day: string;
  date: string;
  title: string;
  time: string;
}

export const CALENDAR_EVENTS: CalendarEvent[] = [
  { day: "MON", date: "6", title: "Board catch-up", time: "09:00" },
  { day: "WED", date: "8", title: "Strategy review", time: "14:00" },
  { day: "FRI", date: "10", title: "Research readout", time: "11:30" },
];

export interface ProjectStatus {
  name: string;
  tag: string;
  progress: number;
  tagColor: "cyan" | "amber" | "emerald" | "violet";
}

export const PROJECTS: ProjectStatus[] = [
  { name: "Governance Reasoning Framework", tag: "In review", progress: 78, tagColor: "cyan" },
  { name: "Market Research Pipeline", tag: "In progress", progress: 62, tagColor: "violet" },
  { name: "Board Update Pack", tag: "Due this week", progress: 40, tagColor: "amber" },
  { name: "Q3 Roadmap", tag: "Sequencing", progress: 25, tagColor: "emerald" },
];

export interface Signal {
  kind: "deadline" | "action" | "research" | "note";
  title: string;
  detail: string;
  cta: string;
}

export const SIGNALS: Signal[] = [
  {
    kind: "deadline",
    title: "Board pack due",
    detail: "Governance summary and roadmap slide need a final pass.",
    cta: "Review",
  },
  {
    kind: "action",
    title: "Two threads need a reply",
    detail: "Flagged by HERALD — neither is urgent, both are aging.",
    cta: "Draft",
  },
  {
    kind: "research",
    title: "New market signal detected",
    detail: "A pattern worth a closer look before the strategy session.",
    cta: "Open",
  },
  {
    kind: "note",
    title: "Sequencing conflict",
    detail: "Two active projects are competing for the same week.",
    cta: "Resolve",
  },
];
